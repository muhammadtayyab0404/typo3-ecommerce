<?php

defined('TYPO3') or die('Access denied.');

// Add default RTE configuration
$GLOBALS['TYPO3_CONF_VARS']['RTE']['Presets']['mywebsite'] = 'EXT:mywebsite/Configuration/RTE/Default.yaml';
